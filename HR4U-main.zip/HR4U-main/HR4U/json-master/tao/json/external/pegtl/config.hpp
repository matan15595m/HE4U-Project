// Copyright (c) 2017-2020 Dr. Colin Hirsch and Daniel Frey
// Please see LICENSE for license or visit https://github.com/taocpp/PEGTL/

#ifndef TAO_JSON_PEGTL_CONFIG_HPP
#define TAO_JSON_PEGTL_CONFIG_HPP

#if !defined( TAO_JSON_PEGTL_NAMESPACE )
#define TAO_JSON_PEGTL_NAMESPACE tao::json::pegtl
#endif

#endif
